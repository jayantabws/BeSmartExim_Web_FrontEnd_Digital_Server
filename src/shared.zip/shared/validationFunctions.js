export const checkGreaterTimes = (time1, time2) => {
    if (time1 != '' && time2 != '') {
        let time3 = new Date(time1);
        let time4 = new Date(time2);
        
        if (time3.getTime() > time4.getTime()) {
            return true;
        }
    }
    return false;
}

export const checkGreaterStartEndTimes = (time1, time2) => {
    if (time1 != '' && time2 != '') {
        let time3 = new Date(time1);
        let time4 = new Date(time2);
        
        if (time3.getTime() < time4.getTime()) {
            return true;
        }
    }
    
    if(typeof time2 == 'undefined'){
        return true;
    }

    return false;
}

