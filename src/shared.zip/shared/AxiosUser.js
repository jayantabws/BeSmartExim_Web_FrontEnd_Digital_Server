import axios from 'axios';
import * as AppConstant from '../components/AppConstant';

const instance = axios.create({
    baseURL: AppConstant.API_USER_URL
});

// Add a request interceptor
instance.interceptors.request.use(config => {
    const userId = localStorage.getItem("userToken");
    config.headers['Access-Control-Allow-Origin'] = "*";
    config.headers['Access-Control-Allow-Headers'] = "Content-Type";
    if (userId) {
        config.headers['accessedBy'] = userId;
    }
    return config;
}, error => {
    return Promise.reject(error);
});

// Add a response interceptor
instance.interceptors.response.use(response => {
    return response;
}, error => {
    return Promise.reject(error.response);
});

export default instance;